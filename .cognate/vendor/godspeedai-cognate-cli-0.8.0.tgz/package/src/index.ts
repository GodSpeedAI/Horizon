// CG-CLI-001 (spec §37 Phase 10): `cognate create` (starter generation with profiles) and `cognate dev`
// (runtime + Connect + AG-UI + UI server). `create` has two modes. With `--source <checkout>` it vendors the
// `@godspeedai/*` packages a profile needs from that checkout with `bun pm pack` and pins them with `file:`
// dependencies plus a package.json `overrides` map, so `workspace:*` inside the packed tarballs resolves outside
// the workspace (unreleased local changes). Without `--source` (registry mode) it pins each `@godspeedai/cognate-*`
// dependency to the CLI's own version, which is released in lockstep with every cognate package (DEBT-016).
import { createHash } from "node:crypto";
import { existsSync } from "node:fs";
import { cp, mkdir, readdir, readFile, rename, writeFile } from "node:fs/promises";
import { basename, join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import type { RuntimeService } from "@godspeedai/cognate-runtime-api";

export interface CreateOptions {
  readonly dir: string;
  readonly profile: "copilot" | "harness";
  /**
   * Optional path to a Cognate source checkout whose packages are packed and vendored (unreleased local changes).
   * When absent, `@godspeedai/cognate-*` dependencies resolve from the npm registry at the CLI's version.
   */
  readonly source?: string;
  /** Optional components requested beyond the profile; unsupported ones are reported and never imported. */
  readonly with?: readonly string[];
}

export interface CreateReport {
  readonly dir: string;
  readonly files: readonly string[];
  readonly vendored: readonly string[];
  readonly unsupported: readonly { readonly name: string; readonly reason: string }[];
}

/** `--with` names the starter cannot yet wire up, with a specific reason where one is known. */
const KNOWN_UNSUPPORTED: Readonly<Record<string, string>> = {
  sona: "SONA was rejected as a ranker (ADR-0005); adaptive ranking is built in via @godspeedai/cognate-capabilities createOutcomeRanker (UCB1)",
};

/** Root `@godspeedai/*` package names a generated app's own package.json depends on, per profile. */
const PROFILE_ROOTS: Readonly<Record<CreateOptions["profile"], readonly string[]>> = {
  copilot: ["@godspeedai/cognate-cli", "@godspeedai/cognate-profile-copilot", "@godspeedai/cognate-domainforge", "@godspeedai/cognate-provider-local"],
  harness: ["@godspeedai/cognate-cli", "@godspeedai/cognate-profile-harness", "@godspeedai/cognate-domainforge", "@godspeedai/cognate-provider-local"],
};

async function copyDir(srcDir: string, destDir: string): Promise<void> {
  await mkdir(destDir, { recursive: true });
  await cp(srcDir, destDir, { recursive: true });
  // The packaged template stores .gitignore as _gitignore (npm drops .gitignore files); restore the dot name.
  if (existsSync(join(destDir, "_gitignore"))) await rename(join(destDir, "_gitignore"), join(destDir, ".gitignore"));
}

/** Maps every `@godspeedai/*` package name in `--source` to its directory, by reading each package.json. */
async function indexCognatePackages(source: string): Promise<Map<string, string>> {
  const byName = new Map<string, string>();
  for (const group of ["packages", "profiles"]) {
    const groupDir = join(source, group);
    if (!existsSync(groupDir)) continue;
    for (const entry of await readdir(groupDir, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      const pkgDir = join(groupDir, entry.name);
      const pkgJsonPath = join(pkgDir, "package.json");
      if (!existsSync(pkgJsonPath)) continue;
      const manifest = JSON.parse(await readFile(pkgJsonPath, "utf8")) as { readonly name?: string };
      if (manifest.name) byName.set(manifest.name, pkgDir);
    }
  }
  return byName;
}

/** BFS over `@godspeedai/*` `dependencies` edges from `roots`, returning every reachable package name (roots included). */
async function transitiveClosure(roots: readonly string[], byName: ReadonlyMap<string, string>): Promise<string[]> {
  const seen = new Set<string>();
  const queue = [...roots];
  while (queue.length > 0) {
    const name = queue.shift()!;
    if (seen.has(name)) continue;
    const pkgDir = byName.get(name);
    if (!pkgDir) throw new Error(`cognate create: cannot find source package "${name}" under --source`);
    seen.add(name);
    const manifest = JSON.parse(await readFile(join(pkgDir, "package.json"), "utf8")) as { readonly dependencies?: Readonly<Record<string, string>> };
    for (const dep of Object.keys(manifest.dependencies ?? {})) {
      // Only workspace packages are vendored; the adapter's pinned external
      // dependency (@godspeedai/domainforge) resolves from the registry.
      if (dep.startsWith("@godspeedai/") && !seen.has(dep) && byName.has(dep)) queue.push(dep);
    }
  }
  return [...seen];
}

/** `bun pm pack --quiet --destination` into `destination`; stdout is the tarball's full path. */
async function packPackage(pkgDir: string, destination: string): Promise<string> {
  const proc = Bun.spawn(["bun", "pm", "pack", "--quiet", "--destination", destination], { cwd: pkgDir, stdout: "pipe", stderr: "pipe" });
  const [exit, stdout, stderr] = await Promise.all([proc.exited, new Response(proc.stdout).text(), new Response(proc.stderr).text()]);
  if (exit !== 0) throw new Error(`cognate create: "bun pm pack" failed in ${pkgDir}: ${stderr}`);
  const outputPath = stdout.trim().split("\n").filter(Boolean).pop();
  if (!outputPath) throw new Error(`cognate create: "bun pm pack" produced no output in ${pkgDir}`);
  return basename(outputPath);
}

/** The starter template inside a Cognate checkout (src/ -> packages/cli -> repo root). */
const CHECKOUT_TEMPLATE_ROOT = fileURLToPath(new URL("../../../templates/starter", import.meta.url));

/** The starter template copied into the published package at pack time (scripts/prepare-npm-package.mjs). */
const PACKAGED_TEMPLATE_ROOT = fileURLToPath(new URL("../templates/starter", import.meta.url));

/** Registry mode reads the packaged template; a checkout run without a packaged copy falls back to the repo root. */
function registryTemplateRoot(): string {
  return existsSync(PACKAGED_TEMPLATE_ROOT) ? PACKAGED_TEMPLATE_ROOT : CHECKOUT_TEMPLATE_ROOT;
}

/**
 * The CLI's own version (packages/cli/package.json). `package.json` is always published by npm, so this resolves
 * from both the checkout and the installed package.
 */
async function cliVersion(): Promise<string> {
  const manifest = JSON.parse(await readFile(new URL("../package.json", import.meta.url), "utf8")) as { readonly version?: string };
  if (!manifest.version) throw new Error("cognate create: the CLI package.json has no version");
  return manifest.version;
}

/** Generate a starter app from templates/starter for a profile. */
export async function create(options: CreateOptions): Promise<CreateReport> {
  const dir = resolve(options.dir);
  const source = options.source === undefined ? undefined : resolve(options.source);
  const templateRoot = source === undefined ? registryTemplateRoot() : join(source, "templates", "starter");
  if (!existsSync(templateRoot)) throw new Error(`cognate create: no template at ${templateRoot}`);

  await mkdir(dir, { recursive: true });
  await copyDir(join(templateRoot, "common"), dir);
  await copyDir(join(templateRoot, options.profile), dir);
  const files = ["domain", "src/agents", "src/capabilities", "src/components", "src/projections", "src/ui", "test", "cognate.config.ts", "package.json"];
  const unsupported = (options.with ?? []).map((name) => ({ name, reason: KNOWN_UNSUPPORTED[name] ?? `not available in the starter yet: ${name}` }));

  const pkgPath = join(dir, "package.json");
  const manifest = JSON.parse(await readFile(pkgPath, "utf8")) as {
    dependencies?: Record<string, string>;
    overrides?: Record<string, string>;
    [key: string]: unknown;
  };
  manifest.dependencies ??= {};

  if (source === undefined) {
    // Registry mode: nothing is packed or vendored and no `overrides` are written; npm resolves the cognate packages.
    const version = await cliVersion();
    for (const key of Object.keys(manifest.dependencies)) {
      if (manifest.dependencies[key] === "workspace:*") manifest.dependencies[key] = version;
    }
    for (const name of PROFILE_ROOTS[options.profile]) manifest.dependencies[name] = version;
    await writeFile(pkgPath, `${JSON.stringify(manifest, null, 2)}\n`);
    return { dir, files, vendored: [], unsupported };
  }

  const byName = await indexCognatePackages(source);
  const closure = await transitiveClosure(PROFILE_ROOTS[options.profile], byName);

  const vendorDir = join(dir, ".cognate", "vendor");
  await mkdir(vendorDir, { recursive: true });
  const fileDepFor = new Map<string, string>();
  for (const name of closure) {
    const filename = await packPackage(byName.get(name)!, vendorDir);
    fileDepFor.set(name, `file:./.cognate/vendor/${filename}`);
  }

  manifest.overrides = { ...(manifest.overrides ?? {}) };
  for (const name of closure) manifest.overrides[name] = fileDepFor.get(name)!;
  for (const key of Object.keys(manifest.dependencies)) {
    if (manifest.dependencies[key] === "workspace:*") manifest.dependencies[key] = fileDepFor.get(key) ?? manifest.dependencies[key]!;
  }
  await writeFile(pkgPath, `${JSON.stringify(manifest, null, 2)}\n`);

  return { dir, files, vendored: closure, unsupported };
}

export interface CognateConfig {
  readonly profile: "copilot" | "harness";
  readonly instructions?: string;
  /** Canonical organizational world: entry is a logical path under domain/, e.g. domain/organization.sea. */
  readonly semanticWorld?: { readonly entry: string; readonly name: string; readonly registryContentHash?: string };
}

export interface DevServer {
  readonly url: string;
  stop(): Promise<void>;
}

const BROWSER_ENTRY = `
import { createElement } from "react";
import { createRoot } from "react-dom/client";
import { createClient } from "@godspeedai/cognate-client";
import { CognateProvider } from "@godspeedai/cognate-react";
import { CognateShell, ChatPanel } from "@godspeedai/cognate-ui-astryx";
import { connectTransport, devToken } from "@godspeedai/cognate-protocol-connect-bun";
import { createRemoteRuntimeService } from "@godspeedai/cognate-protocol-connect";

const caller = { tenant: "local", actor: { id: "dev", kind: "user" } };
const transport = connectTransport(window.location.origin);
const service = createRemoteRuntimeService(transport, () => devToken(caller));
const client = createClient({ service, caller });

const root = document.getElementById("root");
if (root) {
  createRoot(root).render(
    createElement(
      CognateProvider,
      { client },
      createElement(CognateShell, { title: "Cognate Starter" }, createElement(ChatPanel, { agent: "agent.copilot", placeholder: "Say something..." })),
    ),
  );
}
`;

function indexHtml(): string {
  return `<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<title>Cognate Starter</title>
<link rel="stylesheet" href="/astryx.css" />
<link rel="stylesheet" href="/theme.css" />
</head>
<body>
<div id="root"></div>
<script type="module" src="/app.js"></script>
</body>
</html>
`;
}

/**
 * Run an app directory: load `cognate.config.ts`, parse `domain/*.sea` through the DomainForge adapter, create the
 * runtime on `.cognate/app.sqlite`, and serve `/health`, Connect (`/cognate.v1.RuntimeService/*`), AG-UI (`/agui`),
 * and the profile UI (`/`).
 */
export async function dev(options: { readonly dir: string; readonly port: number }): Promise<DevServer> {
  const dir = resolve(options.dir);
  const configPath = join(dir, "cognate.config.ts");
  if (!existsSync(configPath)) throw new Error(`cognate dev: no cognate.config.ts in ${dir}`);
  const { default: config } = (await import(pathToFileURL(configPath).href)) as { default: CognateConfig };

  const { loadSemanticProjection, loadSemanticWorld } = await import("@godspeedai/cognate-domainforge");
  const domainDir = join(dir, "domain");
  const sources: Record<string, string> = {};
  if (existsSync(domainDir)) {
    // Paths are logical IDs under domain/, not guessed namespace names.
    // Traverse recursively so imports may live in nested directories.
    const visit = async (current: string, prefix: string): Promise<void> => {
      for (const item of await readdir(current, { withFileTypes: true })) {
        const relative = prefix ? `${prefix}/${item.name}` : item.name;
        if (item.isDirectory()) await visit(join(current, item.name), relative);
        else if (item.isFile() && item.name.endsWith(".sea")) {
          sources[`domain/${relative}`] = await readFile(join(current, item.name), "utf8");
        }
      }
    };
    await visit(domainDir, "");
  }

  const objects: { readonly id: string; readonly kind: string; readonly name: string }[] = [];
  let worldRef: string | undefined;
  let semanticClosureHash: string | undefined;
  let digest: string;
  const fileNames = Object.keys(sources).sort();
  if (config.semanticWorld) {
    const result = loadSemanticWorld({
      entry: config.semanticWorld.entry,
      sources,
      worldName: config.semanticWorld.name,
      registryContentHash: config.semanticWorld.registryContentHash,
    });
    if (!result.ok) throw new Error(`cognate dev: organizational world resolution failed: ${JSON.stringify(result.error)}`);
    for (const object of result.projection.objects) objects.push({ id: object.ref.id, kind: object.kind, name: object.name });
    worldRef = result.worldRef;
    digest = result.projection.source.digest;
    semanticClosureHash = result.identity.semantic_closure_hash;
  } else {
    // Legacy single-module starter support. Combining independent file digests is not a
    // canonical world; reject ambiguous multi-file worlds instead of advertising one.
    if (fileNames.length > 1) {
      throw new Error("cognate dev: multiple .sea files require semanticWorld { entry, name } in cognate.config.ts");
    }
    const digestParts: string[] = [];
    for (const file of fileNames) {
      const result = loadSemanticProjection(sources[file]!, { uri: file });
      if (!result.ok) throw new Error(`cognate dev: failed to parse ${file}: ${JSON.stringify(result.error)}`);
      for (const object of result.projection.objects) objects.push({ id: object.ref.id, kind: object.kind, name: object.name });
      digestParts.push(result.projection.source.digest);
    }
    digest = `sha256:${createHash("sha256").update(digestParts.join("|")).digest("hex")}`;
  }

  await mkdir(join(dir, ".cognate"), { recursive: true });
  const storePath = join(dir, ".cognate", "app.sqlite");

  let agents: string[];
  let components: string[];
  let agUi: ((request: Request) => Promise<Response>) | undefined;
  let runtimeService: RuntimeService;
  let closeApp: () => Promise<void>;

  if (config.profile === "copilot") {
    const { createCopilotApp, COPILOT_AGENT, copilotRegistry } = await import("@godspeedai/cognate-profile-copilot");
    const { localProvider } = await import("@godspeedai/cognate-provider-local");
    const app = await createCopilotApp({
      store: storePath,
      model: localProvider({ id: "starter", rules: [{ respond: () => ({ message: { role: "assistant", content: "Hello from the Cognate starter." }, toolCalls: [], finishReason: "stop" }) }] }),
      instructions: config.instructions,
    });
    agents = [COPILOT_AGENT];
    components = copilotRegistry.map((entry) => entry.name);
    agUi = app.agUi;
    runtimeService = app.runtime.service;
    closeApp = () => app.close();
  } else {
    const { createHarness, LOOP_AGENT, harnessRegistry, providerComponent } = await import("@godspeedai/cognate-profile-harness");
    const { localProvider } = await import("@godspeedai/cognate-provider-local");
    const harness = await createHarness({ store: storePath, instructions: config.instructions });
    await harness.mount(providerComponent(localProvider({ id: "starter" })));
    agents = [LOOP_AGENT];
    components = harnessRegistry.map((entry) => entry.name);
    runtimeService = harness.runtime.service;
    closeApp = () => harness.close();
  }

  const { serveRuntime, devTokenAuthenticator } = await import("@godspeedai/cognate-protocol-connect-bun");
  // Dev-only auth: `Bearer <tenant>:<principalId>` (see devTokenAuthenticator); never for production use.
  const internal = serveRuntime({ service: runtimeService, authenticate: devTokenAuthenticator, port: 0, hostname: "127.0.0.1" });

  let bundleJs: string | undefined;
  let cssPaths: readonly string[] = [];
  if (config.profile === "copilot") {
    const { stylesheetPaths } = await import("@godspeedai/cognate-ui-astryx/styles");
    cssPaths = stylesheetPaths();
    const entryPath = join(dir, ".cognate", "entry.tsx");
    await writeFile(entryPath, BROWSER_ENTRY);
    const build = await Bun.build({ entrypoints: [entryPath], target: "browser", format: "esm" });
    if (!build.success) throw new Error(`cognate dev: failed to bundle the UI: ${build.logs.map((log) => String(log)).join("; ")}`);
    bundleJs = await build.outputs[0]!.text();
  }

  const healthPayload = { ok: true, semantic: { objects: objects.length, digest, ...(worldRef ? { worldRef, semanticClosureHash } : {}) }, agents, components };

  const server = Bun.serve({
    port: options.port,
    hostname: "127.0.0.1",
    async fetch(request) {
      const url = new URL(request.url);
      if (url.pathname === "/health") return Response.json(healthPayload);
      if (url.pathname.startsWith("/cognate.v1.RuntimeService/")) {
        const init: RequestInit & { duplex?: "half" } = { method: request.method, headers: request.headers, body: request.body };
        if (request.body) init.duplex = "half";
        return fetch(new Request(internal.url + url.pathname + url.search, init));
      }
      if (agUi && url.pathname === "/agui" && request.method === "POST") return agUi(request);
      if (config.profile === "copilot") {
        if (url.pathname === "/app.js" && bundleJs !== undefined) return new Response(bundleJs, { headers: { "content-type": "text/javascript" } });
        if (url.pathname === "/astryx.css" && cssPaths[0]) return new Response(Bun.file(cssPaths[0]));
        if (url.pathname === "/theme.css" && cssPaths[1]) return new Response(Bun.file(cssPaths[1]));
        if (url.pathname === "/") return new Response(indexHtml(), { headers: { "content-type": "text/html" } });
      } else if (url.pathname === "/") {
        return Response.json(healthPayload);
      }
      return new Response("not found", { status: 404 });
    },
  });

  return {
    url: `http://127.0.0.1:${server.port}`,
    async stop() {
      server.stop(true);
      await internal.stop();
      await closeApp();
    },
  };
}
